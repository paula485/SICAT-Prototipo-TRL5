# SICAT – Sistema Web para la Gestión de Citas en Consultorios Odontológicos Pequeños (TRL5)

Proyecto académico de Ingeniería de Sistemas – **UNAD** (Curso: *Proyecto de grado – 202016907*, Fase 4 – Componente práctico).

## Alcance del Prototipo (TRL5)
- Gestión administrativa de citas odontológicas en entorno simulado con datos 100 % ficticios.
- Control de acceso por roles (`Administrador`, `Recepcion`, `Odontologo`).
- Validación de disponibilidad y prevención de cruces de horario mediante procedimiento almacenado (`sp_VerificarConflictoCita`).
- Exclusión expresa de historias clínicas, diagnósticos o facturación.

## Estructura del repositorio
- `database/SICAT_Schema_Seed.sql`: Script DDL de creación de tablas, restricciones, datos ficticios y validación anti-colisión.
- `src/Controllers/CitasController.cs`: Controlador base para consulta de agenda, creación y validación de citas.
- `src/Services/DisponibilidadService.cs`: Servicio de verificación de disponibilidad y solapamiento horario.
- `src/Views/Citas/Index.cshtml`: Vista web de agenda y programación de citas.
- `docs/Arquitectura_y_Pruebas_TRL5.md`: Resumen técnico del prototipo y matriz de pruebas P01–P10.
