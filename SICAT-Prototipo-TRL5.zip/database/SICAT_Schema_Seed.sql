-- =====================================================================
-- SICAT: Sistema Web para la Gestión de Citas en Consultorios Odontológicos
-- Script de Base de Datos (SQL Server Express) - Nivel TRL5
-- Datos 100 % ficticios / simulados (sin información clínica)
-- =====================================================================

IF DB_ID('SICAT_DB') IS NULL
BEGIN
    CREATE DATABASE SICAT_DB;
END
GO

USE SICAT_DB;
GO

-- 1. Roles
CREATE TABLE Rol (
    id_rol INT IDENTITY(1,1) PRIMARY KEY,
    nombre_rol VARCHAR(30) NOT NULL UNIQUE
);

-- 2. Usuarios del sistema
CREATE TABLE Usuario (
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    nombre_completo VARCHAR(100) NOT NULL,
    correo_usuario VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(256) NOT NULL,
    id_rol INT NOT NULL,
    activo BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_Usuario_Rol FOREIGN KEY (id_rol) REFERENCES Rol(id_rol)
);

-- 3. Profesionales odontológicos
CREATE TABLE Profesional (
    id_profesional INT IDENTITY(1,1) PRIMARY KEY,
    nombres_apellidos VARCHAR(100) NOT NULL,
    especialidad VARCHAR(60) NOT NULL,
    registro_profesional VARCHAR(30) NOT NULL UNIQUE,
    activo BIT NOT NULL DEFAULT 1
);

-- 4. Horarios laborales por profesional
CREATE TABLE Horario (
    id_horario INT IDENTITY(1,1) PRIMARY KEY,
    id_profesional INT NOT NULL,
    dia_semana TINYINT NOT NULL CHECK (dia_semana BETWEEN 1 AND 7),
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    CONSTRAINT FK_Horario_Profesional FOREIGN KEY (id_profesional) REFERENCES Profesional(id_profesional),
    CONSTRAINT CK_Horario_Rango CHECK (hora_fin > hora_inicio)
);

-- 5. Citas administrativas (sin datos clínicos)
CREATE TABLE Cita (
    id_cita INT IDENTITY(1,1) PRIMARY KEY,
    id_profesional INT NOT NULL,
    fecha_cita DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    paciente_nombre VARCHAR(100) NOT NULL,
    paciente_documento VARCHAR(20) NOT NULL,
    paciente_telefono VARCHAR(20) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Programada',
    observacion_admin VARCHAR(200) NULL,
    creado_por INT NOT NULL,
    CONSTRAINT FK_Cita_Profesional FOREIGN KEY (id_profesional) REFERENCES Profesional(id_profesional),
    CONSTRAINT FK_Cita_Usuario FOREIGN KEY (creado_por) REFERENCES Usuario(id_usuario),
    CONSTRAINT CK_Cita_Rango CHECK (hora_fin > hora_inicio),
    CONSTRAINT CK_Cita_Estado CHECK (estado IN ('Programada', 'Reprogramada', 'Cancelada', 'Atendida'))
);
GO

-- Datos iniciales ficticios
INSERT INTO Rol (nombre_rol) VALUES ('Administrador'), ('Recepcion'), ('Odontologo');

INSERT INTO Usuario (nombre_completo, correo_usuario, password_hash, id_rol, activo) VALUES
('Admin Demo SICAT', 'admin@sicat.local', 'HASH_DEMO_PBKDF2_ADMIN', 1, 1),
('Recepcion Demo SICAT', 'recepcion@sicat.local', 'HASH_DEMO_PBKDF2_RECEPCION', 2, 1),
('Dra. Laura Gomez Demo', 'lgomez@sicat.local', 'HASH_DEMO_PBKDF2_ODONTO', 3, 1);

INSERT INTO Profesional (nombres_apellidos, especialidad, registro_profesional, activo) VALUES
('Dra. Laura Gomez', 'Odontologia General', 'OD-1001-SIM', 1),
('Dr. Carlos Rojas', 'Ortodoncia', 'OD-1002-SIM', 1);

INSERT INTO Horario (id_profesional, dia_semana, hora_inicio, hora_fin) VALUES
(1, 1, '08:00:00', '12:00:00'),
(1, 1, '14:00:00', '18:00:00'),
(1, 2, '08:00:00', '12:00:00'),
(2, 1, '09:00:00', '13:00:00');

INSERT INTO Cita (id_profesional, fecha_cita, hora_inicio, hora_fin, paciente_nombre, paciente_documento, paciente_telefono, estado, observacion_admin, creado_por) VALUES
(1, '2026-11-24', '08:00:00', '08:30:00', 'Paciente Ficticio Uno', '1000000001', '3000000001', 'Programada', 'Valoracion inicial simulada', 2),
(1, '2026-11-24', '09:00:00', '09:30:00', 'Paciente Ficticio Dos', '1000000002', '3000000002', 'Programada', 'Control administrativo simulado', 2);
GO

-- Validación contra conflicto de horario (RNF03)
CREATE OR ALTER PROCEDURE sp_VerificarConflictoCita
    @IdProfesional INT,
    @FechaCita DATE,
    @HoraInicio TIME,
    @HoraFin TIME,
    @IdCitaExcluir INT = 0,
    @TieneConflicto BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1
        FROM Cita
        WHERE id_profesional = @IdProfesional
          AND fecha_cita = @FechaCita
          AND estado IN ('Programada', 'Reprogramada')
          AND id_cita <> @IdCitaExcluir
          AND (@HoraInicio < hora_fin AND @HoraFin > hora_inicio)
    )
        SET @TieneConflicto = 1;
    ELSE
        SET @TieneConflicto = 0;
END;
GO
