using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace SICAT.Controllers
{
    public class CitaDto
    {
        public int IdCita { get; set; }
        public int IdProfesional { get; set; }
        public string NombreProfesional { get; set; } = string.Empty;
        public DateTime FechaCita { get; set; }
        public TimeSpan HoraInicio { get; set; }
        public TimeSpan HoraFin { get; set; }
        public string PacienteNombre { get; set; } = string.Empty;
        public string Estado { get; set; } = "Programada";
    }

    public class CitasController : Controller
    {
        private static readonly List<CitaDto> _citasSimuladas = new()
        {
            new CitaDto
            {
                IdCita = 1,
                IdProfesional = 1,
                NombreProfesional = "Dra. Laura Gomez",
                FechaCita = new DateTime(2026, 11, 24),
                HoraInicio = new TimeSpan(8, 0, 0),
                HoraFin = new TimeSpan(8, 30, 0),
                PacienteNombre = "Paciente Ficticio Uno",
                Estado = "Programada"
            }
        };

        public IActionResult Index()
        {
            return View(_citasSimuladas);
        }

        [HttpPost]
        public IActionResult Crear(CitaDto nuevaCita)
        {
            if (string.IsNullOrWhiteSpace(nuevaCita.PacienteNombre) || nuevaCita.HoraFin <= nuevaCita.HoraInicio)
            {
                TempData["Error"] = "Verifique los campos obligatorios y el rango de horas.";
                return RedirectToAction(nameof(Index));
            }

            bool hayCruce = false;
            foreach (var c in _citasSimuladas)
            {
                if (c.IdProfesional == nuevaCita.IdProfesional &&
                    c.FechaCita.Date == nuevaCita.FechaCita.Date &&
                    c.Estado != "Cancelada" &&
                    nuevaCita.HoraInicio < c.HoraFin &&
                    nuevaCita.HoraFin > c.HoraInicio)
                {
                    hayCruce = true;
                    break;
                }
            }

            if (hayCruce)
            {
                TempData["Error"] = "Conflicto de horario: el profesional ya tiene una cita en esa franja.";
                return RedirectToAction(nameof(Index));
            }

            nuevaCita.IdCita = _citasSimuladas.Count + 1;
            nuevaCita.Estado = "Programada";
            _citasSimuladas.Add(nuevaCita);
            TempData["Exito"] = "Cita registrada correctamente en SICAT.";
            return RedirectToAction(nameof(Index));
        }
    }
}
