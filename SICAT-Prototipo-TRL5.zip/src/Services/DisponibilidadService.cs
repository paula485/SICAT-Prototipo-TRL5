using System;

namespace SICAT.Services
{
    public class DisponibilidadService
    {
        public bool ExisteSolapamiento(
            TimeSpan inicioExistente,
            TimeSpan finExistente,
            TimeSpan inicioNueva,
            TimeSpan finNueva)
        {
            return inicioNueva < finExistente && finNueva > inicioExistente;
        }
    }
}
