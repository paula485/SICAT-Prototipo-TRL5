# Arquitectura y Resumen de Pruebas – SICAT (TRL5)

- **Metodología:** Scrum adaptado a desarrollo individual (4 Sprints).
- **Arquitectura:** 4 capas (Presentación, Controladores, Servicios de Negocio, Persistencia).
- **Base de datos:** SQL Server Express (`SICAT_DB`) con entidades `Rol`, `Usuario`, `Profesional`, `Horario` y `Cita`.
- **Estado de pruebas:** 10/10 casos de prueba (P01–P10) verificados en entorno simulado con datos ficticios.
